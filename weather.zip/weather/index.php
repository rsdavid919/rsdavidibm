<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Weather-Based Clothing Recommendation</title>
    
    <!-- Google Fonts for modern typography -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500&display=swap" rel="stylesheet">
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background: linear-gradient(to right, #f5f7fa, #c3cfe2);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .container {
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            padding: 40px;
            width: 100%;
            max-width: 600px;
            margin-top: 20px;
        }
        h1 {
            font-weight: 500;
            font-size: 28px;
            color: #333;
        }
        .form-label {
            font-weight: 500;
            color: #555;
        }
        .btn-primary {
            background-color: #007bff;
            border: none;
            transition: background-color 0.3s ease;
        }
        .btn-primary:hover {
            background-color: #0056b3;
        }
        .loading {
            display: none;
            text-align: center;
        }
        .error {
            color: red;
            text-align: center;
            font-weight: 500;
        }
        #result {
            margin-top: 20px;
            display: none;
        }
        #result h3 {
            font-size: 22px;
            font-weight: 500;
            color: #333;
        }
        .weather-info p {
            margin-bottom: 10px;
        }
        .clothing-images-container img {
            max-width: 100px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            margin-right: 10px;
        }
        /* Styling for weather results card */
        .weather-card {
            background-color: #f8f9fa;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            margin-top: 20px;
        }
        .weather-card p {
            font-size: 16px;
            color: #333;
        }
    </style>
</head>
<body>

<div class="container">
    <h1 class="text-center mb-4">Weather-Based Clothing Recommendation</h1>
    <div class="row justify-content-center">
        <div class="col-md-12">
            <form id="weatherForm">
                <div class="mb-3">
                    <label for="city" class="form-label">Enter City:</label>
                    <input type="text" id="city" name="city" class="form-control" placeholder="e.g., Manila" required>
                    <div class="form-text">Enter the city to get clothing recommendations based on weather conditions.</div>
                </div>
                <button type="submit" class="btn btn-primary w-100">Get Recommendation</button>
            </form>

            <!-- Loading Indicator -->
            <div class="loading mt-3">
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>
            </div>

            <!-- Error Message -->
            <div class="error mt-3" id="errorMessage" style="display: none;">Error: Unable to fetch weather data. Please try again later.</div>

            <!-- Weather Result Display -->
            <div id="result">
                <div class="weather-card">
                    <h3 class="text-center">Weather in <span id="cityName"></span></h3>
                    <div class="weather-info">
                        <p><strong>Temperature:</strong> <span id="temp"></span>°C</p>
                        <p><strong>Weather Condition:</strong> <span id="weather"></span></p>
                        <p><strong>Wind Speed:</strong> <span id="wind"></span> kph</p>
                        <p><strong>Precipitation:</strong> <span id="precipitation"></span> mm</p>
                        <p><strong>Clothing Recommendation:</strong> <span id="recommendation"></span></p>
                    </div>

                    <!-- Container for Clothing Images -->
                    <div class="clothing-images-container mt-3" id="clothingImages">
                        <!-- Images will be dynamically added here -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    document.getElementById("weatherForm").addEventListener("submit", function (e) {
        e.preventDefault();

        document.getElementById("errorMessage").style.display = "none";
        document.getElementById("result").style.display = "none";
        document.getElementById("clothingImages").innerHTML = "";  // Clear previous images

        const city = document.getElementById("city").value.trim();
        if (city === "") {
            alert("Please enter a valid city.");
            return;
        }

        document.querySelector(".loading").style.display = "block";

        fetch(`weather_clothing_recommendation.php?city=${city}`)
            .then(response => response.json())
            .then(data => {
                document.querySelector(".loading").style.display = "none";

                if (data.error) {
                    document.getElementById("errorMessage").innerText = data.error;
                    document.getElementById("errorMessage").style.display = "block";
                } else {
                    document.getElementById("cityName").innerText = data.city;
                    document.getElementById("temp").innerText = data.temperature;
                    document.getElementById("weather").innerText = data.weather;
                    document.getElementById("wind").innerText = data.wind;
                    document.getElementById("precipitation").innerText = data.precipitation;
                    document.getElementById("recommendation").innerText = data.clothing_recommendation;

                    // Display clothing images based on recommendation
                    const images = getClothingImages(data.clothing_recommendation);
                    const clothingImagesContainer = document.getElementById("clothingImages");
                    images.forEach(img => {
                        const imgElement = document.createElement("img");
                        imgElement.src = img;
                        imgElement.classList.add("clothing-image");
                        clothingImagesContainer.appendChild(imgElement);
                    });

                    document.getElementById("result").style.display = "block";
                }
            })
            .catch(error => {
                document.querySelector(".loading").style.display = "none";
                document.getElementById("errorMessage").innerText = "Error: Unable to fetch weather data. Please try again later.";
                document.getElementById("errorMessage").style.display = "block";
            });
    });

    // Function to return clothing image URLs based on the recommendation
    function getClothingImages(recommendation) {
        const images = [];

        if (recommendation.includes("light clothing")) {
            images.push("images/tshirt.jpg", "images/shorts.jpg");
        }
        if (recommendation.includes("t-shirt and jeans")) {
            images.push("images/tshirt.jpg", "images/jeans.jpg");
        }
        if (recommendation.includes("jacket or a sweater")) {
            images.push("images/jacket.jpg", "images/sweater.jpg");
        }
        if (recommendation.includes("warm coat")) {
            images.push("images/coat.jpg");
        }
        if (recommendation.includes("umbrella")) {
            images.push("images/umbrella.jpg");
        }
        if (recommendation.includes("wind-resistant clothing")) {
            images.push("images/wind-resistant.jpg");
        }

        return images;
    }
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

