<?php
// Set your WeatherAPI API key
$apiKey = "5514bdaf444b408f803160450240411";  

// Get city from query string and sanitize the input to prevent malicious inputs
$city = isset($_GET['city']) ? trim($_GET['city']) : ''; 

// Ensure city input is not empty
if (empty($city)) {
    die(json_encode(["error" => "Please enter a valid city or country name."]));
}

// WeatherAPI URL for current weather (using the sanitized city or country input)
$currentWeatherUrl = "http://api.weatherapi.com/v1/current.json?key={$apiKey}&q=" . urlencode($city) . "&aqi=no";

// Fetch current weather data
$currentWeatherData = @file_get_contents($currentWeatherUrl);  // The "@" suppresses warnings if the URL fails
if ($currentWeatherData === FALSE) {
    die(json_encode(["error" => "Invalid city or country name. Please try again."]));
}

$currentWeatherData = json_decode($currentWeatherData, true);

// Check if the API response contains location data (valid city/country)
if (!isset($currentWeatherData['location']['name'])) {
    die(json_encode(["error" => "Invalid location. Please provide a valid city or country name."]));
}

// Extract relevant data from WeatherAPI response
$temperature = $currentWeatherData['current']['temp_c'];
$weatherCondition = $currentWeatherData['current']['condition']['text'];
$windSpeed = $currentWeatherData['current']['wind_kph'];
$precipitation = $currentWeatherData['current']['precip_mm'];

// Function to get clothing recommendation based on temperature, wind, and precipitation
function getClothingRecommendation($temp, $wind, $precipitation) {
    if ($temp >= 30) {
        $recommendation = "It's very hot outside. Wear light clothing such as shorts and a t-shirt.";
    } elseif ($temp >= 20) {
        $recommendation = "It's warm outside. A t-shirt and jeans should be fine.";
    } elseif ($temp >= 10) {
        $recommendation = "It's a bit chilly. Wear a jacket or a sweater.";
    } else {
        $recommendation = "It's cold. Make sure to wear a warm coat.";
    }

    // Additional clothing suggestions based on precipitation and wind
    if ($precipitation > 0) {
        $recommendation .= " Carry an umbrella as it may rain.";
    }

    if ($wind >= 25) {
        $recommendation .= " It's windy, so consider wearing wind-resistant clothing.";
    }

    return $recommendation;
}

// Get clothing recommendation
$clothingRecommendation = getClothingRecommendation($temperature, $windSpeed, $precipitation);

// Output the result in JSON format
$result = [
    "city" => $currentWeatherData['location']['name'],
    "temperature" => $temperature,
    "weather" => $weatherCondition,
    "wind" => $windSpeed,
    "precipitation" => $precipitation,
    "clothing_recommendation" => $clothingRecommendation
];

header('Content-Type: application/json');
echo json_encode($result, JSON_PRETTY_PRINT);
?>
